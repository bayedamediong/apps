package entity;

public interface IChemise {
    Chemise saisie(); // Méthode pour saisir une chemise
    void affichage(Chemise c); // Méthode pour afficher les détails d'une chemise
}