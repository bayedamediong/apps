package entity;

public interface IArticle {
    Article saisie(); // Méthode pour saisir un article
    void affichage(Article a); // Méthode pour afficher les détails d'un article
}