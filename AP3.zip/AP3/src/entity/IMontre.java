package entity;

public interface IMontre {
    Montre saisie(); // Méthode pour saisir une montre
    void affichage(Montre m); // Méthode pour afficher les détails d'une montre
}