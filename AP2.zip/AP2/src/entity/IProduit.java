package entity;

public interface IProduit {
    Produit saisie(); // Méthode pour saisir un produit
    void affichage(Produit produit); // Méthode pour afficher un produit
}
